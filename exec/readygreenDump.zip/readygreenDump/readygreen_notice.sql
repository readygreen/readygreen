-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: readygreen
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `create_date` datetime(6) DEFAULT NULL,
  `content` varchar(500) NOT NULL,
  `is_important` bit(1) NOT NULL,
  `title` varchar(100) NOT NULL,
  `member_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKnriaekshh15qoqnlhvqkj931e` (`member_id`),
  CONSTRAINT `FKnriaekshh15qoqnlhvqkj931e` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (191,'2024-09-30 09:00:00.000000','안녕하세요. 시스템 점검이 2024년 10월 5일 오후 10시부터 6시간 동안 진행될 예정입니다. 점검 시간 동안 서비스 이용이 불가능하오니 참고 부탁드립니다.',_binary '','시스템 점검 안내',2),(192,'2024-09-28 09:30:00.000000','안녕하세요. 이번 업데이트에서는 용원이가 업데이트되었습니다. 더 나은 서비스 제공을 위해 노력하겠습니다.',_binary '','신규 신호 업데이트 공지',2),(193,'2024-09-30 10:00:00.000000','2024년 11월 1일부터 새로운 서비스 이용 약관이 적용됩니다. 변경된 약관은 공지사항에서 확인하실 수 있습니다.',_binary '','포인트 증정 이벤트 안내',2),(194,'2024-09-08 00:00:00.000000','효율적으로 앱을 사용하는 팁을 확인하세요! 경로 설정부터 알림 설정까지 쉽게 설명해 드립니다.',_binary '\0','앱 사용 팁',2),(195,'2024-09-10 00:00:00.000000','최근 교통 상황을 반영한 신호등 정보를 업데이트했습니다. 안전하게 이용해 주세요.',_binary '\0','신호등 정보 반영',14),(196,'2024-09-12 00:00:00.000000','시스템 점검이 완료되었습니다. 안정적인 서비스 제공을 위해 노력하겠습니다.',_binary '\0','서비스 점검 완료',2),(197,'2024-09-14 00:00:00.000000','갑작스러운 날씨 변화에 대비해 우산을 챙기세요. 안전한 보행을 위한 안내를 참고해 주세요.',_binary '\0','보행자 안전 주의사항',14),(198,'2024-09-16 00:00:00.000000','알림 설정을 통해 중요한 정보를 빠르게 받아보세요. 설정 방법은 앱 내 가이드를 참고하세요.',_binary '\0','알림 설정 방법 안내',2),(199,'2024-09-18 00:00:00.000000','긴급 서버 점검이 진행될 예정입니다. 점검 시간 동안 일부 서비스 이용이 제한될 수 있습니다.',_binary '\0','긴급 점검 공지',14),(200,'2024-09-20 00:00:00.000000','여러분의 소중한 의견을 바탕으로 앱의 다양한 기능을 개선했습니다.',_binary '\0','사용자 피드백 반영',2),(201,'2024-09-22 00:00:00.000000','낮 시간이 짧아지는 가을철, 보행자 안전에 주의해 주세요. 안전한 경로 안내를 이용하세요.',_binary '\0','가을철 보행자 안전',14),(202,'2024-09-24 00:00:00.000000','사용자 경험을 개선하기 위해 만족도 조사를 진행합니다. 참여 부탁드립니다.',_binary '\0','앱 사용자 만족도 조사',2),(203,'2024-09-26 00:00:00.000000','정기 점검이 진행됩니다. 점검 시간 동안 서비스 이용이 일시적으로 중단될 수 있습니다.',_binary '\0','정기 점검 안내',14),(204,'2024-09-28 00:00:00.000000','앱의 다양한 기능을 최대한 활용하기 위한 가이드를 제공합니다. 더 많은 정보를 알아보세요.',_binary '\0','앱 이용 가이드',2),(205,'2024-09-30 00:00:00.000000','최신 보행자 데이터를 반영하여 경로 안내의 정확성을 높였습니다.',_binary '\0','보행자 통계 업데이트',14),(206,'2024-10-02 00:00:00.000000','운동량을 늘리고 건강한 보행 습관을 길러보세요. 앱에서 추천하는 경로를 이용해 보세요.',_binary '\0','건강한 보행 습관',2),(207,'2024-10-04 00:00:00.000000','여러분의 의견을 소중히 여기며, 이를 바탕으로 앱 성능을 더욱 향상시켰습니다.',_binary '\0','이용자 의견 반영',14),(208,'2024-10-06 00:00:00.000000','추석 연휴 기간 동안 교통 혼잡이 예상됩니다. 안전한 경로 안내를 이용해 주세요.',_binary '\0','추석 연휴 교통 상황',2),(209,'2024-10-08 00:00:00.000000','처음 앱을 사용하시는 분들을 위한 가이드를 제공합니다. 편리하게 이용해 보세요.',_binary '\0','신규 사용자 안내',14);
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 12:54:01
