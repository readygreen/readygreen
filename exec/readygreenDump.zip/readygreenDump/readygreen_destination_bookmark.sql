-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: readygreen
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `destination_bookmark`
--

DROP TABLE IF EXISTS `destination_bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `destination_bookmark` (
  `id` int NOT NULL AUTO_INCREMENT,
  `create_date` datetime(6) DEFAULT NULL,
  `alert_time` time(6) DEFAULT NULL,
  `destination_coordinate` point NOT NULL /*!80003 SRID 4326 */,
  `destination_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('COMPANY','ETC','HOME') NOT NULL,
  `member_id` int DEFAULT NULL,
  `place_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKi81472adv3ow7ae0dm5ift1mi` (`member_id`),
  CONSTRAINT `FKi81472adv3ow7ae0dm5ift1mi` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destination_bookmark`
--

LOCK TABLES `destination_bookmark` WRITE;
/*!40000 ALTER TABLE `destination_bookmark` DISABLE KEYS */;
INSERT INTO `destination_bookmark` VALUES (42,'2024-10-06 21:05:16.989475','00:00:00.000000',_binary '\�\0\0\0\0\0A��j\�_@�B\��-B@','대한민국 대전광역시 유성구 봉명동 682-2','기타','ETC',65,'ChIJu-5uD5pLZTURNHqj_GI60wg'),(43,'2024-10-06 21:05:30.269243','00:00:00.000000',_binary '\�\0\0\0\0\0x\�|٬\�_@7�\�-B@','대한민국 대전광역시 유성구 봉명동 669','집','HOME',65,'ChIJcdF58ZZLZTURSG5w7xmMYjo'),(61,'2024-10-08 14:49:16.907062','00:00:00.000000',_binary '\�\0\0\0\0\0���\�\�_@8\�\�\�,B@','대한민국 대전광역시 유성구 학하서로121번길 17-14','회사','COMPANY',72,'ChIJ958bRrNMZTURm30LNjauLGA'),(62,'2024-10-08 17:38:33.607279','00:00:00.000000',_binary '\�\0\0\0\0\0�M�>3\�_@\��E\�,B@','대한민국 대전광역시 유성구 덕명동 산16-1','기타','ETC',14,'ChIJ0RMk_7NMZTURZtoSvuWu9yA'),(63,'2024-10-08 17:38:57.269480','00:00:00.000000',_binary '\�\0\0\0\0\0c\�\Z?�_@)\�	��\�B@','105 YTN 서울타워 1층 110 111, 남산공원길 용산동2가 용산구 서울특별시 대한민국','집','HOME',72,'ChIJ_4VJd7yjfDUR04NOJEqTtB0'),(64,'2024-10-08 17:38:57.968052','00:00:00.000000',_binary '\�\0\0\0\0\0��һ�_@U\��Q\�\�B@','대한민국 서울특별시 중구 명동8가길 22 IB타워 2층','기타','ETC',72,'ChIJy2DnyQ2jfDURQj9don6TouA'),(65,'2024-10-08 17:38:58.714652','00:00:00.000000',_binary '\�\0\0\0\0\0���_@�[��\�\�B@','대한민국 서울특별시 중구 퇴계로 210','기타','ETC',72,'ChIJsdDLL8mjfDURpjjijQDd_X4'),(67,'2024-10-08 17:53:34.602749','00:00:00.000000',_binary '\�\0\0\0\0\0\rV�#�\�_@T\�UP-B@','대한민국 대전광역시 유성구 계룡로66번길 16','기타','ETC',65,'ChIJ0Ts923hLZTURwkW1h5s3ao0'),(68,'2024-10-08 21:03:16.404364','00:00:00.000000',_binary '\�\0\0\0\0\0��	E\�_@T.\�\�,B@','대한민국 대전광역시 유성구 동서대로 125','기타','ETC',72,'ChIJz4A-TrJMZTUR9vLQP0ud638'),(70,'2024-10-09 00:52:26.259876','00:00:00.000000',_binary '\�\0\0\0\0\0RC�\�\Z\�_@��A\�,B@','대한민국 대전광역시 서구 둔산2동 둔산로 32-30','기타','ETC',14,'ChIJjTRx2eZLZTURB66voQckfRk'),(74,'2024-10-09 19:34:28.937081','00:00:00.000000',_binary '\�\0\0\0\0\0�䑉%\�_@v\��u,B@','대한민국 대전광역시 유성구 덕명동 171-10','기타','ETC',69,'ChIJn-OR8rRMZTUR3CTy4pznI-A'),(75,'2024-10-09 19:34:44.821452','00:00:00.000000',_binary '\�\0\0\0\0\0M?�\�_@�vdQ}-B@','대한민국 대전광역시 유성구 덕명동 122-1','기타','ETC',69,'ChIJPdvdIq1MZTUR7qgo3qBBO3I'),(76,'2024-10-09 20:15:27.290829','00:00:00.000000',_binary '\�\0\0\0\0\0\�jY�\�_@\�\�l.B@','대한민국 대전광역시 유성구 장대동 346-8','회사','COMPANY',66,'ChIJ1yTa8HVLZTURus6-ch_TBJ8'),(77,'2024-10-09 20:16:22.190426','00:00:00.000000',_binary '\�\0\0\0\0\0�񎝁\�_@\"?\n�.B@','대한민국 대전광역시 장대동 323-2번지 103동 2104호 유성구 대전광역시 KR','집','HOME',66,'ChIJQW2KInRLZTURCnfXk1pyQQA'),(78,'2024-10-09 20:52:46.623681','00:00:00.000000',_binary '\�\0\0\0\0\0ڇa,�\�_@��rf-B@','대한민국 대전광역시 유성구 계룡로105번길 28 1 2. 3.층','기타','ETC',84,'ChIJy7MhbnBLZTURGvH3c1JRLmQ'),(79,'2024-10-09 20:53:32.060653','00:00:00.000000',_binary '\�\0\0\0\0\0�Q�k\�_@����.B@','대한민국 대전광역시 유성구 온천2동 대학로151번길 66','집','HOME',84,'ChIJeYi09ChLZTURriMzxq2UGS0'),(80,'2024-10-09 20:53:43.235073','00:00:00.000000',_binary '\�\0\0\0\0\0\�\�\�_@�\'\�\�o-B@','대한민국 대전광역시 유성구 덕명동 124','회사','COMPANY',84,'ChIJqcqCPa1MZTURf7b0yi3O-7M'),(81,'2024-10-09 21:24:39.183341','00:00:00.000000',_binary '\�\0\0\0\0\0d���k\�_@6aV��.B@','대한민국 대전광역시 유성구 대학로151번길 66','집','HOME',85,'ChIJGxWrtqJLZTURS5I47haP8NA'),(82,'2024-10-09 21:56:01.821389','00:00:00.000000',_binary '\�\0\0\0\0\0\Z0\�@\�\�_@\�c���,B@','대한민국 대전광역시 유성구 도안대로 573','기타','ETC',69,'ChIJCcnX4YFLZTUR32RNEAmQEwc'),(83,'2024-10-09 22:33:49.103211','00:00:00.000000',_binary '\�\0\0\0\0\0�N\�\�_@q\�^��.B@','대한민국 대전광역시 유성구 유성대로822번길 16','기타','ETC',66,'ChIJCYlYd3VLZTURjgrm_rPRph8'),(84,'2024-10-10 01:15:09.427204','00:00:00.000000',_binary '\�\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','대전 유성구 도안대로577번길 12','기타','ETC',69,'7591'),(85,'2024-10-10 09:14:54.584117','00:00:00.000000',_binary '\�\0\0\0\0\0�~�\�_@�\"��\�,B@','대한민국 대전광역시 유성구 덕명동 615-1','기타','ETC',72,'ChIJs3PEMLNMZTUROYHuWT82XPg'),(88,'2024-10-10 10:01:13.484767','00:00:00.000000',_binary '\�\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','대전 유성구 동서대로 125 1층','기타','ETC',14,'31816'),(101,'2024-10-10 10:50:16.317330','00:00:00.000000',_binary '\�\0\0\0\0\0�l\��)\�_@���\�x,B@','대한민국 대전광역시 유성구 덕명동 613-1','기타','ETC',14,'ChIJEw874X1LZTURsuwCjxfBot0'),(112,'2024-10-10 10:57:38.326540','00:00:00.000000',_binary '\�\0\0\0\0\0���\�\�_@8\�\�\�,B@','대한민국 대전광역시 유성구 학하서로121번길 17-14','기타','ETC',84,'ChIJ958bRrNMZTURm30LNjauLGA');
/*!40000 ALTER TABLE `destination_bookmark` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 12:53:53
